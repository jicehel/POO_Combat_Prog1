#ifndef GAME_H
#define GAME_H

typedef struct{
  int gameStatus; 
}GameInfo;

#define TITLESCREEN  1
#define ROUND        2
#define PAUSE        3
#define GAMEOVER     4

#define NB_HEALTHPOINTS 50

#define MAX_NAME_LENGTH 32

#define TimeBeforeNextScreen 650

#endif
